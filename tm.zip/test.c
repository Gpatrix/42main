#include "libft.h"

#include <bsd/string.h>



static void	*foo(void *content)
{
	return (content);
}

static void	delet(void *to_del)
{
	free (to_del);
}

int	main(void)
{
	t_list	*test_lst = NULL;

	test_lst = ft_lstnew("test 1");
 	ft_lstlast(test_lst)->next = ft_lstnew("test 2");
 	ft_lstlast(test_lst)->next = ft_lstnew("test 3");
 	ft_lstlast(test_lst)->next = ft_lstnew("test 4");

	printf("origin: %p | ", test_lst);
	test_lst = ft_lstmap(test_lst, foo, delet);
	printf("map: %p\n", test_lst);

	while (test_lst && test_lst->content)
	{
		printf("%s ", (char *)test_lst->content);
		test_lst = test_lst->next;
	}

	return (0);
}
