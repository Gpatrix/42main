/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   test.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lchauvet <lchauvet@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/23 09:34:06 by lchauvet          #+#    #+#             */
/*   Updated: 2024/10/25 09:36:57 by lchauvet         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "includes/ft_printf.h"
#include "includes/libft.h"
#include "assert.h"

int	main(void)
{
	int *test;

	test = malloc(1 * sizeof(int));

	*test = 25;
	printf(" | %i \n", ft_printf("%i, %d, %x, %s ", INT_MIN, INT_MIN, INT_MIN,"test"));
	printf(" | %i \n", printf("%i, %d, %x, %s ", INT_MIN, INT_MIN, INT_MIN,"test"));
	return (0);
}
