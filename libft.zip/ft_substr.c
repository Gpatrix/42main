/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_substr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lchauvet <lchauvet@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/16 10:33:31 by lchauvet          #+#    #+#             */
/*   Updated: 2024/10/17 17:13:31 by lchauvet         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_substr(char const *s, unsigned int start, size_t len)
{
	char	*new_str;
	char	*str_origine;

	new_str = malloc((sizeof(char) * len) + 1);
	if (!new_str)
		return (NULL);
	str_origine = new_str;
	s += start;
	while (*s && len--)
		*new_str++ = *s++;
	*new_str = '\0';
	return (str_origine);
}
