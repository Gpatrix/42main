/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstclear.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lchauvet <lchauvet@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/17 15:59:17 by lchauvet          #+#    #+#             */
/*   Updated: 2024/10/17 17:08:02 by lchauvet         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_lstclear(t_list **lst, void (*del)(void*))
{
	t_list	*tmp_lst;

	if (!lst)
		return ;

	tmp_lst = lst[0]->next;
		ft_lstdelone(lst[0], del);
		lst[0] = tmp_lst;
	while (lst[0]->next != NULL)
	{
		tmp_lst = lst[0]->next;
		ft_lstdelone(lst[0], del);
		lst[0] = tmp_lst;
	}
	lst = NULL;
}
