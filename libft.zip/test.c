#include "libft.h"

#include <bsd/string.h>

void	delet(void *to_del)
{
	free (to_del);
}

int	main(void)
{
	printf("%s", ft_itoa(INT_MIN));
	return (0);
}



