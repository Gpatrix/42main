#include "libft.h"

#include <bsd/string.h>


int	main(void)
{
	printf("%s\n", ft_substr("hola", 4294967295, 0));
}
