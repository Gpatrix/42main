#include "libft.h"

#include <bsd/string.h>

void	delet(void *to_del)
{
	free (to_del);
}

int main() 
{
	char str[] = "le mot de plus";
	char charset = ' ';
	char **result;
	int i;

	result = ft_split(str, charset);

	i = 0;
	while (result[i])
	{
		printf("Word %d: %s\n", i, result[i]);
		// free(result[i]);
		i++;
	}
	free(result);

	return (0);
}




